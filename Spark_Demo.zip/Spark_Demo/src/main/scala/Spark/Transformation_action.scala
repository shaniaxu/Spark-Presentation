
import org.apache.spark.{SparkConf,SparkContext}

object Transformation_action {

  def main(arg: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("EX")

    val sc = new SparkContext(conf)


    // map:
    val x0 = sc.parallelize(Array("b", "a", "c"))
    val y0 = x0.map(z => (z,1))
    println("result of map: "+y0.collect().mkString(", "))


    //Group by first letter
    val x = sc.parallelize(Array("Anne", "Mathieu", "Huyen", "Jean"))
    val y = x.groupBy(w => w.charAt(0))
    println(y.collect().mkString(", "))

    //Group by key vs reduce by key
    val x1 = sc.parallelize(Array(('B',5),('B',4),('A',3),('A',2),('A',1)))
    val y1 = x1.groupByKey()
    val yy= x1.reduceByKey(_+_)
    println("result of Groupbykey: "+y1.collect().mkString(", "))
    println("result of Reducebykey: "+y1.collect().mkString(", "))


    //Sampling:
    val x2 = sc.parallelize(Array(1, 2, 3, 4, 5))
    val y2 = x2.sample(false, 0.4)

    // omitting seed will yield different output
    println("result of sampling: "+y2.collect().mkString(", "))


    //Zip:
    val z = x.zip(y)
    println("result of zip: "+z.collect().mkString(", "))


    // partition:
    val x3 = sc.parallelize(Array(1,2,3), 2)
    val y3 = x3.partitions.size
    println("result of partition: "+y3)


   //flatmap:
    val x4 = sc.parallelize(Array(1,2,3))
    val y4 = x4.flatMap(n => Array(n, n*100, 42))
    println("result of flatmap: "+y4.collect().mkString(", "))


    //reduce:
    val x5 = sc.parallelize(Array(1,2,3,4))
    val y5 = x5.reduce((a,b) => a+b)
    println("result of reduce: "+y5)

    //count by key:

    val x6 = sc.parallelize(Array(('J',"James"),('F',"Fred"), ('A',"Anna"),('J',"John")))
    val y6 = x6.countByKey()

    println("result of countbykey: "+y6)


    //Filter:

    val x7 = sc.parallelize(Array(1,2,3))
    val y7 = x7.filter(n => n%2 == 1)
    println("result of filter: "+y7.collect().mkString(", "))


    //Union:
    val x8 = sc.parallelize(Array(1,2,3))
    val y8 = sc.parallelize(Array(3,4,1))
    val z8 = x8.union(y8)
    println("result of union: "+z8.collect().mkString(", "))

    //Join:
    val x9 = sc.parallelize(Array(("a", 1), ("b", 2)))
    val y9 = sc.parallelize(Array(("a", 3), ("a", 4), ("b", 5)))
    val z9 = x9.join(y9)
    println("result of join :"+z9.collect().mkString(", "))


      }

}
