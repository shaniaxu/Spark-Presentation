
import org.apache.spark.sql.SparkSession

//create data schema
case class Activity
(MonthAndYear:String, InboundOutbout:String, Local:String,
 Internationalcity:String, Airline:String, Route:String, PortCouontry:String, PortRegion:String, ServiceCountry:String, ServiceRegion:String, Stops:String, NumerberOfFlights:String, Maxseats:String)

case class Codes
(AirlineCode:String,Airline:String,Company:String,Country:String)

object  Spark_Analyse {

  def main(arg: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("spark").master("local").config("configuration key", "configuration value").getOrCreate
    val sqlContext = spark.sqlContext

    import spark.implicits._
   // create dataframe and load data
    val activitydf=spark.read.format("csv").option("inferSchema", true).load("activity.csv").toDF("MonthAndYear", "InboundOutbout", "Local", "Internationalcity",
      "Airline", "Route", "PortCouontry", "PortRegion", "ServiceCountry", "ServiceRegion", "Stops",
      "NumerberOfFlights", "Maxseats")

    val codesdf=spark.read.format("csv").option("inferSchema",true).load("codes.csv").toDF("AirlineCode","Airline","Company","Country")
   // convert dataframe to dataset
    val activityds = activitydf.as[Activity]
    val codesds = codesdf.as[Codes]

    activityds.printSchema()
    codesds.printSchema()
    activityds.show()
    codesds.show()

    //create temp view to query
    activityds.createOrReplaceTempView("activity")
    codesds.createOrReplaceTempView("codes")

    // use spark sql for data query
    val query1=spark.sql("select sum(Maxseats) as sumSeats, airline from activity group by Airline order by sumSeats desc")
    query1.show()

    val query2=spark.sql("select activity.Airline, codes.AirlineCode,sum(activity.MaxSeats) as sumSeats from activity join codes on activity.Airline=codes.Airline group by activity.Airline,codes.AirlineCode order by sumSeats desc")
    query2.show()

    val query3=spark.sql("select concat(substring(MonthAndYear, 4, 4), substring(MonthAndYear, 1, 2)) as MonthAndYear, Airline, sum(MaxSeats) from activity group by Airline, MonthAndYear order by Airline, MonthAndYear")
    query3.show()

  }

}